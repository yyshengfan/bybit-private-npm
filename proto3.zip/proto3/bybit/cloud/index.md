bybit.cloud
===========

> cloud是业务整个大的业务方向，为整个cbu团队提供基础能力支撑，这里会对接主站（账户体系，行情，交易，资产等），也会对接外部交易所。

## [**user**](./user/v1beta1)

https://confluence.yijin.io/display/BC/User+service+detail+design