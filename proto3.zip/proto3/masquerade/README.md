鉴权（登录态）维护服务

https://git.bybit.com/svc/masquerade
