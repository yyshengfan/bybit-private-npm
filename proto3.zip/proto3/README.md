## protobuf定义仓库

本仓库位于`svc/proto3`，其他仓库可能引用，如果你在其他仓库子目录看见本目录，**请勿提交直接修改，按后述工作流程修改并review**

**注意事项**

+ 本仓库仅master分支为准
+ 原则上仅作后向兼容的变更，需要不兼容的变更时，必须拉所有相关人员讨论

**工作流程**

1. fork仓库到自己名字下并提交修改
2. 提交Merge Request请相关同学review通过
3. 现在相关仓库应该均支持自动生成，等待机器人push生成结果即可 ~~// 到项目相关生成仓库（如svc/idl）中执行拉去和生成相关命令~~

如果公共仓库中已经有修改，提MR前需要自己Rebase，[见此页面](https://confluence.yijin.io/display/backend/Fork-rebase-merge+request)

**参考资料**

subrepo介绍 <https://confluence.yijin.io/display/backend/git+subrepo>
