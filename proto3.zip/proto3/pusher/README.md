### pusher 目录中idl定义说明 ###
* privatev2/ 中存放
本目录存放v2.5版 json格式的私有推送数据结构定义:
1. enums复用,输出string形式
   (后续可能考虑单独拆一份前端实际用到的精简版枚举出来,保证二进制值兼容)
   (为了兼容老版本json,可能会有一些值是alias)
2. 底层使用的XxxDTO会重新定义成XxxItem,用胶水代码做相互转换
   底层int64的e8/e4 => 输出成double值的e8/e4 (输出成json的number,不带双引号)
3. 时间戳字段输出成google.protobuf.Timestamp 并且将精度修正到毫秒 甚至秒

```
// json输出 浮点数:
//double(精度会乱)
// vs  int64 e8/e4 (带双引号,计算要自己转)
// @3 ***** double e8/e4 (没有双引号,计算要自己转)

// 1. ws2.5推送按新json格式输出
// 2. wallet/position/order的各种查询接口按新json格式输出
// 3. PC和app 上行调用接口 这里先维持兼容
```

* privatev3/ 中存放纯pb格式的推送数据
1. enums复用
2. 底层int64的e8保持不变
3. timestamp相关字段保持不变 输出纳秒int64
