#!/usr/bin/env bash

OUT=$(mktemp -d -t pbcheck.XXXXX)

go install google.golang.org/protobuf/cmd/protoc-gen-go
go install google.golang.org/grpc/cmd/protoc-gen-go-grpc

list_idl_pkg() {
    while read -r line
    do
        dirname ${line:2}
    done < <(_list_idl_files) | sort | uniq
}

_list_idl_files() {
    find . -type f -name \*.proto \
    \( -path ./enums\* \
        -o -path ./models\* \
        -o -path ./svc\* \
        -o -path ./perpetual\* \
        -o -path ./linear\* \
        -o -path ./strategy\* \
        -o -path ./pusher\* \
        -o -path ./dto/insurance\* \
        -o -path ./dto/notification\* \
        -o -path ./api\* \
        -o -path ./option\* \
        -o -path ./unified\* \
        -o -path ./bybit\* \
    \)
}

bye() {
    rm -rf $OUT
    exit $1
}

idl_pkgs=($(list_idl_pkg))
for pkg in "${idl_pkgs[@]}"
do
    echo "making idl $pkg"
    protoc -I. \
        --go_out=paths=source_relative:$OUT \
        --go-grpc_out=paths=source_relative:$OUT \
        $pkg/*.proto
    status=$?
    [[ $status -eq 0 ]] || bye $status
done

bye 0

